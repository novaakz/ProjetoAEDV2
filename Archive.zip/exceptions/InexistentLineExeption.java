package exceptions;

public class InexistentLineExeption extends Exception {
    public InexistentLineExeption() {
        super();
    }
}
