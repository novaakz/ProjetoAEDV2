package exceptions;

public class InvalidScheduleException extends Exception {
    public InvalidScheduleException() {
        super();
    }
}
