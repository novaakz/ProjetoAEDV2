package exceptions;

public class ExistentLineException extends Exception {

    public ExistentLineException() {
        super();
    }
}
