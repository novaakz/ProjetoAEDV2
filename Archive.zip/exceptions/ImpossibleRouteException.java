package exceptions;

public class ImpossibleRouteException extends Exception {
    public ImpossibleRouteException() {
        super();
    }
}
