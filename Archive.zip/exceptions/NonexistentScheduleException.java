package exceptions;

public class NonexistentScheduleException extends Exception {
    public NonexistentScheduleException() {
        super();
    }
}
