package exceptions;

public class NonexistentStationException extends Exception {
    public NonexistentStationException() {
        super();
    }
}
